package com.crmapp.utilities;

public interface EmailService {
	public void sendSimpleMessage(String to,String subject, String text);
}
